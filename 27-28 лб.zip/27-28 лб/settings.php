<?php
require_once 'functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$user = getCurrentUser();
$theme = $user['theme'];
$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['update_profile'])) {
        $name = trim($_POST['name'] ?? '');
        $email = trim($_POST['email'] ?? '');
        
        $error_name = validateName($name);
        $error_email = validateEmail($email);
        
        if ($error_name) {
            $error = $error_name;
        } elseif ($error_email) {
            $error = $error_email;
        } else {
            updateUser($user['id'], $name, $email);
            $success = 'Профиль успешно обновлен!';
            $user = getCurrentUser();
        }
    } elseif (isset($_POST['change_theme'])) {
        $new_theme = $_POST['theme'] ?? 'light';
        updateUserTheme($user['id'], $new_theme);
        $success = 'Тема успешно изменена!';
        $user = getCurrentUser();
        $theme = $new_theme;
    } elseif (isset($_POST['change_password'])) {
        $old_password = $_POST['old_password'] ?? '';
        $new_password = $_POST['new_password'] ?? '';
        $confirm = $_POST['confirm_password'] ?? '';
        
        if (empty($old_password) || empty($new_password)) {
            $error = 'Заполните все поля';
        } elseif ($new_password !== $confirm) {
            $error = 'Пароли не совпадают';
        } elseif (strlen($new_password) < 6) {
            $error = 'Пароль должен быть не менее 6 символов';
        } else {
            $result = changePassword($user['id'], $old_password, $new_password);
            if ($result['success']) {
                $success = $result['message'];
            } else {
                $error = $result['message'];
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Настройки</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="<?php echo $theme; ?>">
    <div class="container">
        <div class="header">
            <div class="logo"><a href="index.php">📓 Личный блокнот</a></div>
            <div class="nav">
                <a href="index.php">🏠 Главная</a>
                <a href="notes.php">📝 Мои заметки</a>
                <a href="settings.php" style="background: #667eea; color: white;">⚙️ Настройки</a>
                <a href="logout.php" class="btn-logout">🚪 Выйти</a>
            </div>
        </div>
        
        <div class="content">
            <h1>⚙️ Настройки</h1>
            
            <?php if ($success): ?>
                <div class="alert alert-success">✅ <?php echo $success; ?></div>
            <?php endif; ?>
            
            <?php if ($error): ?>
                <div class="alert alert-error">❌ <?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <h2>👤 Профиль</h2>
                <form method="POST">
                    <div class="form-group">
                        <label>Логин (нельзя изменить)</label>
                        <input type="text" value="<?php echo htmlspecialchars($user['login']); ?>" disabled>
                    </div>
                    
                    <div class="form-group">
                        <label>Имя</label>
                        <input type="text" name="name" required value="<?php echo htmlspecialchars($user['name']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Email</label>
                        <input type="email" name="email" required value="<?php echo htmlspecialchars($user['email']); ?>">
                    </div>
                    
                    <button type="submit" name="update_profile" class="btn">💾 Сохранить изменения</button>
                </form>
            </div>
            
            <div class="card">
                <h2>🎨 Тема оформления</h2>
                <form method="POST">
                    <div class="form-group">
                        <select name="theme">
                            <option value="light" <?php echo $theme == 'light' ? 'selected' : ''; ?>>Светлая</option>
                            <option value="dark" <?php echo $theme == 'dark' ? 'selected' : ''; ?>>Темная</option>
                            <option value="blue" <?php echo $theme == 'blue' ? 'selected' : ''; ?>>Синяя</option>
                        </select>
                    </div>
                    <button type="submit" name="change_theme" class="btn btn-primary">🎨 Применить тему</button>
                </form>
            </div>
            
            <div class="card">
                <h2>🔐 Смена пароля</h2>
                <form method="POST">
                    <div class="form-group">
                        <label>Текущий пароль</label>
                        <input type="password" name="old_password" required>
                    </div>
                    
                    <div class="form-group">
                        <label>Новый пароль</label>
                        <input type="password" name="new_password" required>
                        <small>Минимум 6 символов</small>
                    </div>
                    
                    <div class="form-group">
                        <label>Подтверждение пароля</label>
                        <input type="password" name="confirm_password" required>
                    </div>
                    
                    <button type="submit" name="change_password" class="btn btn-warning">🔄 Сменить пароль</button>
                </form>
            </div>
            
            <div class="card">
                <h2>📊 Информация</h2>
                <p>Дата регистрации: <?php echo $user['registered_at']; ?></p>
                <p>Всего заметок: <?php echo count(getUserNotes($user['id'])); ?></p>
            </div>
        </div>
        
        <div class="footer">
            <p>Личный блокнот &copy; 2025</p>
        </div>
    </div>
</body>
</html>
