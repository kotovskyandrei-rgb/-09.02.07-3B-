<?php
require_once 'functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$user = getCurrentUser();
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id) {
    deleteNote($id, $user['id']);
}

header('Location: notes.php?success=deleted');
exit();
?>
