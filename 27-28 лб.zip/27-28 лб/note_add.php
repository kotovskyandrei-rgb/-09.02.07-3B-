<?php
require_once 'functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$user = getCurrentUser();
$theme = $user['theme'];
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    
    $error_title = validateNoteTitle($title);
    
    if ($error_title) {
        $error = $error_title;
    } else {
        addNote($user['id'], $title, $content);
        header('Location: notes.php?success=added');
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Новая заметка</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="<?php echo $theme; ?>">
    <div class="container">
        <div class="header">
            <div class="logo"><a href="index.php">📓 Личный блокнот</a></div>
            <div class="nav">
                <a href="index.php">🏠 Главная</a>
                <a href="notes.php">📝 Мои заметки</a>
                <a href="settings.php">⚙️ Настройки</a>
                <a href="logout.php" class="btn-logout">🚪 Выйти</a>
            </div>
        </div>
        
        <div class="content">
            <h1>➕ Новая заметка</h1>
            
            <?php if ($error): ?>
                <div class="alert alert-error">❌ <?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <form method="POST">
                    <div class="form-group">
                        <label>Заголовок *</label>
                        <input type="text" name="title" required value="<?php echo htmlspecialchars($_POST['title'] ?? ''); ?>">
                        <small>От 3 до 100 символов</small>
                    </div>
                    
                    <div class="form-group">
                        <label>Текст заметки</label>
                        <textarea name="content"><?php echo htmlspecialchars($_POST['content'] ?? ''); ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">💾 Сохранить</button>
                    <a href="notes.php" class="btn">Отмена</a>
                </form>
            </div>
        </div>
        
        <div class="footer">
            <p>Личный блокнот &copy; 2025</p>
        </div>
    </div>
</body>
</html>
