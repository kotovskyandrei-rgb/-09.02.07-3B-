<?php
// functions.php - все функции приложения

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ============================================
// ПОДКЛЮЧЕНИЕ К БАЗЕ ДАННЫХ
// ============================================
define('DB_HOST', 'localhost');  // XAMPP
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_NAME', 'notebook_db');

function getConnection() {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        die("Ошибка подключения: " . $conn->connect_error);
    }
    
    $conn->set_charset("utf8mb4");
    return $conn;
}

// ============================================
// ФУНКЦИИ ДЛЯ РАБОТЫ С ПОЛЬЗОВАТЕЛЯМИ
// ============================================

function getUserByLogin($login) {
    $conn = getConnection();
    $stmt = $conn->prepare("SELECT * FROM users WHERE login = ?");
    $stmt->bind_param("s", $login);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    closeConnection($conn);
    return $user;
}

function getUserById($id) {
    $conn = getConnection();
    $stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();
    $stmt->close();
    closeConnection($conn);
    return $user;
}

function registerUser($login, $password, $name, $email) {
    $conn = getConnection();
    
    $check = $conn->prepare("SELECT id FROM users WHERE login = ? OR email = ?");
    $check->bind_param("ss", $login, $email);
    $check->execute();
    $result = $check->get_result();
    
    if ($result->num_rows > 0) {
        $check->close();
        closeConnection($conn);
        return ['success' => false, 'message' => 'Пользователь с таким логином или email уже существует'];
    }
    $check->close();
    
    $password_hash = password_hash($password, PASSWORD_DEFAULT);
    $stmt = $conn->prepare("INSERT INTO users (login, password, name, email) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("ssss", $login, $password_hash, $name, $email);
    
    if ($stmt->execute()) {
        $stmt->close();
        closeConnection($conn);
        return ['success' => true, 'message' => 'Регистрация успешна!'];
    } else {
        $stmt->close();
        closeConnection($conn);
        return ['success' => false, 'message' => 'Ошибка регистрации'];
    }
}

function loginUser($login, $password, $remember = false) {
    $user = getUserByLogin($login);
    
    if (!$user || !password_verify($password, $user['password'])) {
        return ['success' => false, 'message' => 'Неверный логин или пароль'];
    }
    
    $_SESSION['user_id'] = $user['id'];
    $_SESSION['user_login'] = $user['login'];
    $_SESSION['user_name'] = $user['name'];
    $_SESSION['user_email'] = $user['email'];
    $_SESSION['user_theme'] = $user['theme'];
    $_SESSION['logged_in'] = true;
    
    if ($remember) {
        $token = bin2hex(random_bytes(32));
        setcookie('remember_token', $token, time() + (86400 * 30), '/');
        setcookie('remember_login', $login, time() + (86400 * 30), '/');
    }
    
    return ['success' => true];
}

function logoutUser() {
    $_SESSION = [];
    session_destroy();
    setcookie('remember_token', '', time() - 3600, '/');
    setcookie('remember_login', '', time() - 3600, '/');
}

function isLoggedIn() {
    if (isset($_SESSION['logged_in']) && $_SESSION['logged_in'] === true) {
        return true;
    }
    
    if (isset($_COOKIE['remember_token']) && isset($_COOKIE['remember_login'])) {
        $user = getUserByLogin($_COOKIE['remember_login']);
        if ($user) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['user_login'] = $user['login'];
            $_SESSION['user_name'] = $user['name'];
            $_SESSION['user_email'] = $user['email'];
            $_SESSION['user_theme'] = $user['theme'];
            $_SESSION['logged_in'] = true;
            return true;
        }
    }
    
    return false;
}

function getCurrentUser() {
    if (!isLoggedIn()) {
        return null;
    }
    return getUserById($_SESSION['user_id']);
}

function updateUser($user_id, $name, $email) {
    $conn = getConnection();
    $stmt = $conn->prepare("UPDATE users SET name = ?, email = ? WHERE id = ?");
    $stmt->bind_param("ssi", $name, $email, $user_id);
    $result = $stmt->execute();
    $stmt->close();
    closeConnection($conn);
    
    if ($result) {
        $_SESSION['user_name'] = $name;
        $_SESSION['user_email'] = $email;
    }
    
    return $result;
}

function updateUserTheme($user_id, $theme) {
    $conn = getConnection();
    $stmt = $conn->prepare("UPDATE users SET theme = ? WHERE id = ?");
    $stmt->bind_param("si", $theme, $user_id);
    $result = $stmt->execute();
    $stmt->close();
    closeConnection($conn);
    
    if ($result) {
        $_SESSION['user_theme'] = $theme;
    }
    
    return $result;
}

function changePassword($user_id, $old_password, $new_password) {
    $user = getUserById($user_id);
    
    if (!password_verify($old_password, $user['password'])) {
        return ['success' => false, 'message' => 'Неверный текущий пароль'];
    }
    
    $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
    $conn = getConnection();
    $stmt = $conn->prepare("UPDATE users SET password = ? WHERE id = ?");
    $stmt->bind_param("si", $new_hash, $user_id);
    $result = $stmt->execute();
    $stmt->close();
    closeConnection($conn);
    
    if ($result) {
        return ['success' => true, 'message' => 'Пароль успешно изменен'];
    } else {
        return ['success' => false, 'message' => 'Ошибка при смене пароля'];
    }
}

// ============================================
// ФУНКЦИИ ДЛЯ РАБОТЫ С ЗАМЕТКАМИ
// ============================================

function getUserNotes($user_id) {
    $conn = getConnection();
    $stmt = $conn->prepare("SELECT * FROM notes WHERE user_id = ? ORDER BY updated_at DESC");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $notes = [];
    while ($row = $result->fetch_assoc()) {
        $notes[] = $row;
    }
    
    $stmt->close();
    closeConnection($conn);
    return $notes;
}

function getNoteById($note_id, $user_id) {
    $conn = getConnection();
    $stmt = $conn->prepare("SELECT * FROM notes WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $note_id, $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $note = $result->fetch_assoc();
    $stmt->close();
    closeConnection($conn);
    return $note;
}

function addNote($user_id, $title, $content) {
    $conn = getConnection();
    $stmt = $conn->prepare("INSERT INTO notes (user_id, title, content) VALUES (?, ?, ?)");
    $stmt->bind_param("iss", $user_id, $title, $content);
    $result = $stmt->execute();
    $new_id = $stmt->insert_id;
    $stmt->close();
    closeConnection($conn);
    return $result ? $new_id : false;
}

function updateNote($note_id, $user_id, $title, $content) {
    $conn = getConnection();
    $stmt = $conn->prepare("UPDATE notes SET title = ?, content = ?, updated_at = NOW() WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ssii", $title, $content, $note_id, $user_id);
    $result = $stmt->execute();
    $stmt->close();
    closeConnection($conn);
    return $result;
}

function deleteNote($note_id, $user_id) {
    $conn = getConnection();
    $stmt = $conn->prepare("DELETE FROM notes WHERE id = ? AND user_id = ?");
    $stmt->bind_param("ii", $note_id, $user_id);
    $result = $stmt->execute();
    $stmt->close();
    closeConnection($conn);
    return $result;
}

function searchNotes($user_id, $query) {
    $conn = getConnection();
    $search = "%{$query}%";
    $stmt = $conn->prepare("SELECT * FROM notes WHERE user_id = ? AND (title LIKE ? OR content LIKE ?) ORDER BY updated_at DESC");
    $stmt->bind_param("iss", $user_id, $search, $search);
    $stmt->execute();
    $result = $stmt->get_result();
    
    $notes = [];
    while ($row = $result->fetch_assoc()) {
        $notes[] = $row;
    }
    
    $stmt->close();
    closeConnection($conn);
    return $notes;
}

function getNotesStats($user_id) {
    $notes = getUserNotes($user_id);
    $total = count($notes);
    $today = date('Y-m-d');
    $created_today = 0;
    
    foreach ($notes as $note) {
        if (strpos($note['created_at'], $today) === 0) {
            $created_today++;
        }
    }
    
    $last_updated = !empty($notes) ? $notes[0]['updated_at'] : null;
    
    return [
        'total' => $total,
        'created_today' => $created_today,
        'last_updated' => $last_updated
    ];
}

// ============================================
// ФУНКЦИИ ВАЛИДАЦИИ
// ============================================

function validateLogin($login) {
    if (empty($login)) return 'Логин обязателен';
    if (strlen($login) < 3) return 'Логин должен быть не менее 3 символов';
    if (strlen($login) > 50) return 'Логин не должен превышать 50 символов';
    if (!preg_match('/^[a-zA-Z0-9_]+$/', $login)) return 'Логин может содержать только буквы, цифры и подчеркивание';
    return null;
}

function validatePassword($password) {
    if (empty($password)) return 'Пароль обязателен';
    if (strlen($password) < 6) return 'Пароль должен быть не менее 6 символов';
    return null;
}

function validateName($name) {
    if (empty($name)) return 'Имя обязательно';
    if (strlen($name) < 2) return 'Имя должно быть не менее 2 символов';
    if (strlen($name) > 100) return 'Имя не должно превышать 100 символов';
    if (!preg_match('/^[a-zA-Zа-яА-Я\s-]+$/u', $name)) return 'Имя может содержать только буквы, пробелы и дефисы';
    return null;
}

function validateEmail($email) {
    if (empty($email)) return 'Email обязателен';
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) return 'Введите корректный email';
    return null;
}

function validateNoteTitle($title) {
    if (empty($title)) return 'Заголовок обязателен';
    if (strlen($title) < 3) return 'Заголовок должен быть не менее 3 символов';
    if (strlen($title) > 100) return 'Заголовок не должен превышать 100 символов';
    return null;
}

function closeConnection($conn) {
    if ($conn) $conn->close();
}
?>
