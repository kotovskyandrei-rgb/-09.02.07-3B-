<?php
require_once 'functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$user = getCurrentUser();
$theme = $user['theme'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$note = getNoteById($id, $user['id']);

if (!$note) {
    header('Location: notes.php?error=notfound');
    exit();
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($note['title']); ?></title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="<?php echo $theme; ?>">
    <div class="container">
        <div class="header">
            <div class="logo"><a href="index.php">📓 Личный блокнот</a></div>
            <div class="nav">
                <a href="index.php">🏠 Главная</a>
                <a href="notes.php">📝 Мои заметки</a>
                <a href="settings.php">⚙️ Настройки</a>
                <a href="logout.php" class="btn-logout">🚪 Выйти</a>
            </div>
        </div>
        
        <div class="content">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; flex-wrap: wrap; gap: 10px;">
                <h1><?php echo htmlspecialchars($note['title']); ?></h1>
                <div class="actions">
                    <a href="note_edit.php?id=<?php echo $id; ?>" class="btn btn-warning">✏️ Редактировать</a>
                    <a href="note_delete.php?id=<?php echo $id; ?>" class="btn btn-danger" onclick="return confirm('Удалить заметку?')">🗑️ Удалить</a>
                    <a href="notes.php" class="btn">← Назад</a>
                </div>
            </div>
            
            <div class="card">
                <div style="color: #888; margin-bottom: 20px; font-size: 12px;">
                    📅 Создано: <?php echo date('d.m.Y H:i:s', strtotime($note['created_at'])); ?><br>
                    🕐 Обновлено: <?php echo date('d.m.Y H:i:s', strtotime($note['updated_at'])); ?>
                </div>
                <div style="line-height: 1.6; white-space: pre-wrap;">
                    <?php echo nl2br(htmlspecialchars($note['content'])); ?>
                </div>
            </div>
        </div>
        
        <div class="footer">
            <p>Личный блокнот &copy; 2025</p>
        </div>
    </div>
</body>
</html>
