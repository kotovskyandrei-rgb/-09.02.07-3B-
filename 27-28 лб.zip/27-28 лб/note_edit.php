<?php
require_once 'functions.php';

if (!isLoggedIn()) {
    header('Location: login.php');
    exit();
}

$user = getCurrentUser();
$theme = $user['theme'];
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;
$note = getNoteById($id, $user['id']);

if (!$note) {
    header('Location: notes.php?error=notfound');
    exit();
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = trim($_POST['title'] ?? '');
    $content = trim($_POST['content'] ?? '');
    
    $error_title = validateNoteTitle($title);
    
    if ($error_title) {
        $error = $error_title;
    } else {
        updateNote($id, $user['id'], $title, $content);
        header('Location: notes.php?success=updated');
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Редактирование</title>
    <link rel="stylesheet" href="style.css">
</head>
<body class="<?php echo $theme; ?>">
    <div class="container">
        <div class="header">
            <div class="logo"><a href="index.php">📓 Личный блокнот</a></div>
            <div class="nav">
                <a href="index.php">🏠 Главная</a>
                <a href="notes.php">📝 Мои заметки</a>
                <a href="settings.php">⚙️ Настройки</a>
                <a href="logout.php" class="btn-logout">🚪 Выйти</a>
            </div>
        </div>
        
        <div class="content">
            <h1>✏️ Редактирование заметки</h1>
            
            <?php if ($error): ?>
                <div class="alert alert-error">❌ <?php echo $error; ?></div>
            <?php endif; ?>
            
            <div class="card">
                <form method="POST">
                    <div class="form-group">
                        <label>Заголовок *</label>
                        <input type="text" name="title" required value="<?php echo htmlspecialchars($note['title']); ?>">
                    </div>
                    
                    <div class="form-group">
                        <label>Текст заметки</label>
                        <textarea name="content"><?php echo htmlspecialchars($note['content']); ?></textarea>
                    </div>
                    
                    <button type="submit" class="btn btn-primary">💾 Сохранить изменения</button>
                    <a href="notes.php" class="btn">Отмена</a>
                </form>
            </div>
        </div>
        
        <div class="footer">
            <p>Личный блокнот &copy; 2025</p>
        </div>
    </div>
</body>
</html>
