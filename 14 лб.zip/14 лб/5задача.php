<?php

$correct = 0;
$total = 10;

echo "📚 ТРЕНАЖЕР ТАБЛИЦЫ УМНОЖЕНИЯ\n";
echo "==============================\n\n";

for ($i = 1; $i <= $total; $i++) {
    $a = rand(2, 9);
    $b = rand(2, 9);
    $correct_answer = $a * $b;

    // Имитация ответа пользователя (можно заменить на ввод)
    $user_answer = rand($correct_answer - 3, $correct_answer + 3);

    echo "Пример $i: $a × $b = ? ";
    echo "Ваш ответ: $user_answer ";

    if ($user_answer == $correct_answer) {
        echo "✅ Правильно!\n";
        $correct++;
    } else {
        echo "❌ Неправильно! Правильный ответ: $correct_answer\n";
    }
}

$percent = ($correct / $total) * 100;

if ($percent >= 90) {
    $grade = "5 (Отлично)";
} elseif ($percent >= 70) {
    $grade = "4 (Хорошо)";
} elseif ($percent >= 50) {
    $grade = "3 (Удовлетворительно)";
} else {
    $grade = "2 (Неудовлетворительно)";
}

echo "\n📊 РЕЗУЛЬТАТ\n";
echo "Правильных ответов: $correct из $total\n";
echo "Процент правильных: $percent%\n";
echo "Оценка: $grade\n";

?>