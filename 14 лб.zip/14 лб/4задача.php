<?php

function rollDice() {
    return rand(1, 6);
}

$player1_wins = 0;
$player2_wins = 0;
$player1_total = 0;
$player2_total = 0;
$max_score = 0;
$max_round = 0;
$max_player = '';

echo "🎲 ИГРА В КОСТИ\n";
echo "10 раундов\n";
echo "=============\n\n";

for ($round = 1; $round <= 10; $round++) {
    $p1_dice1 = rollDice();
    $p1_dice2 = rollDice();
    $p2_dice1 = rollDice();
    $p2_dice2 = rollDice();

    $p1_sum = $p1_dice1 + $p1_dice2;
    $p2_sum = $p2_dice1 + $p2_dice2;

    $player1_total += $p1_sum;
    $player2_total += $p2_sum;

    // Максимальный бросок
    if ($p1_sum > $max_score) {
        $max_score = $p1_sum;
        $max_round = $round;
        $max_player = 'Игрок 1';
    }
    if ($p2_sum > $max_score) {
        $max_score = $p2_sum;
        $max_round = $round;
        $max_player = 'Игрок 2';
    }

    // Определение победителя раунда
    if ($p1_sum > $p2_sum) {
        $player1_wins++;
        $result = "Победил Игрок 1";
    } elseif ($p2_sum > $p1_sum) {
        $player2_wins++;
        $result = "Победил Игрок 2";
    } else {
        $result = "НИЧЬЯ";
    }

    echo "Раунд $round: Игрок 1 [$p1_dice1+$p1_dice2=$p1_sum] vs Игрок 2 [$p2_dice1+$p2_dice2=$p2_sum] → $result\n";
}

$draws = 10 - ($player1_wins + $player2_wins);
$avg1 = round($player1_total / 10, 1);
$avg2 = round($player2_total / 10, 1);

echo "\n📊 СТАТИСТИКА\n";
echo "Побед: Игрок 1 - $player1_wins, Игрок 2 - $player2_wins, Ничьи - $draws\n";
echo "Средний результат: Игрок 1 - $avg1, Игрок 2 - $avg2\n";
echo "Максимальный бросок: $max_score ($max_player, раунд $max_round)\n";

?>