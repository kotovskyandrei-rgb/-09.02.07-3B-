<?php

$letters = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
$numbers = '0123456789';
$all_chars = $letters . $numbers;

echo "🔐 ГЕНЕРАТОР НАДЕЖНЫХ ПАРОЛЕЙ\n";
echo "==============================\n";

for ($i = 1; $i <= 5; $i++) {
    $password = '';
    $digit_count = 0;

    for ($j = 0; $j < 8; $j++) {
        $random_index = rand(0, strlen($all_chars) - 1);
        $char = $all_chars[$random_index];
        $password .= $char;

        if (is_numeric($char)) {
            $digit_count++;
        }
    }

    // Дополнительное задание: минимум 2 цифры
    if ($digit_count < 2) {
        // Заменяем последний символ на цифру
        $password[rand(0, 7)] = $numbers[rand(0, strlen($numbers) - 1)];
    }

    echo "Пароль $i: $password\n";
}

?>