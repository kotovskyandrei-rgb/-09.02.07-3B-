<?php

$bill = 4500;
$people = 4;
$tip_percent = 10;

$tip_amount = $bill * ($tip_percent / 100);
$total = $bill + $tip_amount;
$per_person = round($total / $people);

echo "🍽️ РЕСТОРАН \"У ПЕТРОВИЧА\"\n";
echo "Счет: $bill руб.\n";
echo "Чаевые ($tip_percent%): $tip_amount руб.\n";
echo "Итого к оплате: $total руб.\n";
echo "👥 Гостей: $people человека\n";
echo "Каждый платит по: $per_person руб.\n";

?>