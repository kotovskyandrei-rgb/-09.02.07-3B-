<?php

$amount = 100000;
$percent = 12;
$months = 12;

$monthly_rate = $percent / 100 / 12;
$payment = $amount * ($monthly_rate * pow(1 + $monthly_rate, $months)) / (pow(1 + $monthly_rate, $months) - 1);
$payment = round($payment);

$total_paid = $payment * $months;
$overpayment = $total_paid - $amount;

echo "🏦 КРЕДИТНЫЙ КАЛЬКУЛЯТОР\n";
echo "Сумма кредита: $amount руб.\n";
echo "Процентная ставка: $percent% годовых\n";
echo "Срок: $months месяцев\n";
echo "Ежемесячный платеж: $payment руб.\n";
echo "Общая сумма выплат: $total_paid руб.\n";
echo "Переплата: $overpayment руб.\n";

?>