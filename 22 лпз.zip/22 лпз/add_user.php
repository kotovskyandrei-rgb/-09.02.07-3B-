<?php
require_once 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $email = $_POST['email'] ?? '';
    $age = $_POST['age'] ?? 0;
    
    if (!empty($username) && !empty($email) && $age > 0) {
        $conn = getConnection();
        $stmt = $conn->prepare("INSERT INTO users (username, email, age) VALUES (?, ?, ?)");
        $stmt->bind_param("ssi", $username, $email, $age);
        
        if ($stmt->execute()) {
            header('Location: users.php?success=1');
        } else {
            header('Location: users.php?error=1');
        }
        
        $stmt->close();
        closeConnection($conn);
    } else {
        header('Location: users.php?error=1');
    }
} else {
    header('Location: users.php');
}
exit();
?>