<?php
// user_detail.php - детальная информация о пользователе
require_once 'config.php';

// Получаем и валидируем ID из URL
$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header('Location: users.php');
    exit;
}

$conn = getConnection();

// Запрашиваем пользователя по ID
$stmt = $conn->prepare("SELECT id, username, email, age, created_at FROM users WHERE id = ?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();
$stmt->close();

if (!$user) {
    closeConnection($conn);
    ?>
    <!DOCTYPE html>
    <html lang="ru">
    <head>
        <meta charset="UTF-8">
        <title>Пользователь не найден</title>
        <link rel="stylesheet" href="style.css">
    </head>
    <body>
    <div class="container">
        <h1>❌ Пользователь не найден</h1>
        <div class="warning">Пользователь с ID <strong><?php echo $id; ?></strong> не существует.</div>
        <div class="menu">
            <a href="users.php" class="btn">← Вернуться к списку</a>
        </div>
    </div>
    </body>
    </html>
    <?php
    exit;
}

closeConnection($conn);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Пользователь: <?php echo htmlspecialchars($user['username']); ?></title>
    <link rel="stylesheet" href="style.css">
    <style>
        .detail-card {
            background: #f8f9fa;
            border-radius: 12px;
            padding: 30px;
            margin: 20px 0;
        }
        .detail-card .avatar {
            width: 80px;
            height: 80px;
            background: linear-gradient(135deg, #667eea, #764ba2);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 32px;
            color: white;
            margin-bottom: 20px;
        }
        .detail-table {
            width: 100%;
            border-collapse: collapse;
        }
        .detail-table tr {
            border-bottom: 1px solid #e0e0e0;
        }
        .detail-table tr:last-child {
            border-bottom: none;
        }
        .detail-table td {
            padding: 14px 10px;
            font-size: 15px;
        }
        .detail-table td:first-child {
            color: #888;
            width: 180px;
            font-weight: 600;
        }
        .detail-table td:last-child {
            color: #333;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>👤 Профиль пользователя</h1>

    <div class="menu">
        <a href="index.php" class="btn">Главная</a>
        <a href="users.php" class="btn">← Список пользователей</a>
    </div>

    <div class="detail-card">
        <div class="avatar">👤</div>
        <table class="detail-table">
            <tr>
                <td>ID</td>
                <td><?php echo $user['id']; ?></td>
            </tr>
            <tr>
                <td>Имя пользователя</td>
                <td><?php echo htmlspecialchars($user['username']); ?></td>
            </tr>
            <tr>
                <td>Email</td>
                <td><?php echo htmlspecialchars($user['email']); ?></td>
            </tr>
            <tr>
                <td>Возраст</td>
                <td><?php echo $user['age']; ?> лет</td>
            </tr>
            <tr>
                <td>Дата регистрации</td>
                <td><?php echo $user['created_at']; ?></td>
            </tr>
        </table>
    </div>

    <div class="menu">
        <a href="users.php" class="btn">← Вернуться к списку</a>
    </div>
</div>
</body>
</html>
