<?php
// delete_user.php - удаление пользователя
require_once 'config.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id <= 0) {
    header('Location: users.php');
    exit;
}

$conn = getConnection();

$stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
$stmt->bind_param("i", $id);

if ($stmt->execute() && $stmt->affected_rows > 0) {
    $stmt->close();
    closeConnection($conn);
    header('Location: users.php?success=3');
} else {
    $stmt->close();
    closeConnection($conn);
    header('Location: users.php?error=1');
}
exit;
?>
